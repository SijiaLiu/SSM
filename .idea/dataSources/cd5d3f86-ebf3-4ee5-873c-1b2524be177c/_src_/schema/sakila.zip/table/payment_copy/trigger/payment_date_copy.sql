CREATE TRIGGER `payment_date_copy`
BEFORE INSERT ON `payment_copy`
FOR EACH ROW
  SET NEW.payment_date = NOW()